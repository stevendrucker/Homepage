﻿app.controller("MainController", function ($scope) {
    $scope.selectedResearch = 0;
    $scope.research = myData.data;


    $scope.primary = _.uniq(_.map(myData.data, function (d) { return d.primary }))

    $scope.tags = ["publication", "year", "collaborators", "subject"];
    $scope.values = {};
    myValues = {};
    //$scope.primary = _.uniq(_.map(myData.data, function (d) { return d.primary }))
    _.each($scope.tags, function (t) {
        $scope.values[t] = _.uniq(_.flatten(_.map(myData.data, function (d) { return d.tags[t] })));
        myValues[t] = _.uniq(_.flatten(_.map(myData.data, function (d) { return d.tags[t] })));
    });

    uniquetags = _.uniq(_.flatten(_.map(myData.data, function (d) { return _.keys(d.tags) })))
    /*
    $portfolio.isotope({ filter: $("li[data-primary='Graphics']") })
    $portfolio.isotope({ filter: $("*") })

    selector = $("li[data-year='2002']li[data-primary='Information']"); // intersection


    _.unique(_.map(selector,function(d) {return d.attributes["data-publication"].value}))
    */
    $scope.$watch('$portfolio', function (newValue, oldValue) {
        alert("portfolio changed");
    });
});


